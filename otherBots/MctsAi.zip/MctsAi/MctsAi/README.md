MctsAi
===

モンテカルロ木探索(MCTS)のUCTにより実装する[FightingICE](http://www.ice.ci.ritsumei.ac.jp/~ftgaic/index.htm)のAI

UCT
---
- 木の深さ:最大2
- ノードを生成する閾値:10
- 試行時間:17ms
